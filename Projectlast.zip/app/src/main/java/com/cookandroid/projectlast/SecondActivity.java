package com.cookandroid.projectlast;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        setTitle("G-L의 동물");

        Button btng = (Button) findViewById(R.id.btng);
        Button btnh = (Button) findViewById(R.id.btnh);
        Button btni = (Button) findViewById(R.id.btni);
    /*    Button btnj = (Button) findViewById(R.id.btnj);
        Button btnk = (Button) findViewById(R.id.btnk);
        Button btnl = (Button) findViewById(R.id.btnl); */
        Button btnBack = (Button) findViewById(R.id.btnB);
        Button btnNext = (Button) findViewById(R.id.btnN);

        btng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),NinActivity.class);
                startActivity(intent);
            }
        });

        btnh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TenActivity.class);
                startActivity(intent);
            }
        });

        btni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ElevenActivity.class);
                startActivity(intent);
            }
        });
/*
        btnj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),NinActivity.class);
                startActivity(intent);
            }
        });

        btnk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TenActivity.class);
                startActivity(intent);
            }
        });

        btnl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ElevenActivity.class);
                startActivity(intent);
            }
        });  */

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),FirstActivity.class);
                startActivity(intent);
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
